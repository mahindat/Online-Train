<!DOCTYPE html>
<html>
<body>


<?php
echo "Welcome to Online Train Bocking System";
?>


<a href="train_reg.php">Train</a>

</body>
</html>
