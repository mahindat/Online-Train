 "Railway Resrevation System"

1. Download the XAMPP Sever

2. Download any Text Editor(Sublime Text, NotePad, Visual Studio Code)

4. Pull the Gihub Code

5. Extract the file and copy "Railway Resrevation System"

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7.Run the script http://localhost/OnlineTrain


**LOGIN DETAILS** 

Admin
user: admin
pass: admin123

